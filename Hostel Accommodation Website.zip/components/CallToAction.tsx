'use client'

import { motion } from 'motion/react'
import { Button } from './ui/button'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Input } from './ui/input'
import { Textarea } from './ui/textarea'
import { Label } from './ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Badge } from './ui/badge'
import { 
  Send, 
  Phone, 
  Mail, 
  MapPin, 
  Star, 
  Users,
  Calendar,
  CheckCircle2
} from 'lucide-react'
import { useState } from 'react'

const testimonials = [
  {
    name: "Rahul Kumar",
    location: "Engineering Student",
    rating: 5,
    comment: "Amazing facilities and great community. The yearly plan saved me a lot of money!"
  },
  {
    name: "Priya Sharma",
    location: "Medical Student", 
    rating: 5,
    comment: "Safe, clean, and convenient. The monthly flexibility was perfect for my schedule."
  },
  {
    name: "Arjun Patel",
    location: "Working Professional",
    rating: 5,
    comment: "Best hostel experience! All inclusive pricing with no hidden costs."
  }
]

export function CallToAction() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    planType: '',
    roomSharing: '',
    message: ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log('Form submitted:', formData)
  }

  return (
    <section id="apply" className="py-20 bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center gap-2 bg-yellow-400/20 text-yellow-300 px-4 py-2 rounded-full mb-4">
            <Star className="w-4 h-4" />
            <span className="font-medium font-body">Get Started</span>
          </div>
          <h2 className="text-4xl md:text-6xl text-white mb-6 font-heading">
            Ready to Join Our
            <span className="block bg-gradient-to-r from-yellow-400 to-teal-400 bg-clip-text text-transparent">
              Community?
            </span>
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto font-body">
            Take the first step towards comfortable, affordable, and vibrant hostel living.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Application Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="border-0 shadow-2xl">
              <CardHeader className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-purple-900 rounded-t-lg">
                <CardTitle className="flex items-center gap-3 text-2xl font-heading">
                  <Send className="w-6 h-6" />
                  Apply Now
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="font-body">Full Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="Enter your full name"
                        required
                        className="font-body"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="font-body">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="Enter your email"
                        required
                        className="font-body"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="font-body">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      placeholder="Enter your phone number"
                      required
                      className="font-body"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="planType" className="font-body">Plan Type</Label>
                      <Select value={formData.planType} onValueChange={(value) => setFormData({...formData, planType: value})}>
                        <SelectTrigger className="font-body">
                          <SelectValue placeholder="Select plan type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="yearly" className="font-body">Yearly Plan</SelectItem>
                          <SelectItem value="monthly" className="font-body">Monthly Plan</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="roomSharing" className="font-body">Room Sharing</Label>
                      <Select value={formData.roomSharing} onValueChange={(value) => setFormData({...formData, roomSharing: value})}>
                        <SelectTrigger className="font-body">
                          <SelectValue placeholder="Select sharing" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2" className="font-body">2 Sharing</SelectItem>
                          <SelectItem value="3" className="font-body">3 Sharing</SelectItem>
                          <SelectItem value="4" className="font-body">4 Sharing</SelectItem>
                          <SelectItem value="5" className="font-body">5 Sharing</SelectItem>
                          <SelectItem value="6" className="font-body">6 Sharing</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="font-body">Message (Optional)</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      placeholder="Any specific requirements or questions?"
                      className="min-h-[100px] font-body"
                    />
                  </div>

                  <Button 
                    type="submit"
                    className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-purple-900 font-medium py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 font-body"
                  >
                    Submit Application
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Contact Info & Stats */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            {/* Contact Information */}
            <Card className="border-0 shadow-lg bg-white/95 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-xl text-purple-900 font-heading">
                  <Phone className="w-5 h-5 text-teal-500" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-teal-500" />
                  <span className="text-gray-700 font-body">+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-cyan-500" />
                  <span className="text-gray-700 font-body">info@bachelorsspace.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-pink-500" />
                  <span className="text-gray-700 font-body">Bachelor's Space, Student Area</span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="border-0 shadow-lg bg-gradient-to-br from-teal-50 to-cyan-50">
              <CardContent className="p-6">
                <div className="grid grid-cols-2 gap-6 text-center">
                  <div>
                    <div className="text-3xl text-teal-600 mb-2 font-heading">500+</div>
                    <div className="text-sm text-gray-600 font-body">Happy Residents</div>
                  </div>
                  <div>
                    <div className="text-3xl text-cyan-600 mb-2 font-heading">98%</div>
                    <div className="text-sm text-gray-600 font-body">Satisfaction Rate</div>
                  </div>
                  <div>
                    <div className="text-3xl text-yellow-600 mb-2 font-heading">24/7</div>
                    <div className="text-sm text-gray-600 font-body">Support Available</div>
                  </div>
                  <div>
                    <div className="text-3xl text-pink-600 mb-2 font-heading">5★</div>
                    <div className="text-sm text-gray-600 font-body">Average Rating</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Testimonials */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl text-white mb-8 font-heading">What Our Residents Say</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 h-full bg-white/95 backdrop-blur">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-gray-700 mb-4 italic font-body">"{testimonial.comment}"</p>
                    <div className="text-center">
                      <div className="font-medium text-purple-900 font-body">{testimonial.name}</div>
                      <div className="text-sm text-gray-500 font-body">{testimonial.location}</div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}